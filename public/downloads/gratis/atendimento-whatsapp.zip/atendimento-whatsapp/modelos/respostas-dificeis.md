# Respostas para os casos difíceis

São respostas de espera: acolhem o cliente sem decidir nada no lugar da loja. Adapte ao que ele disse, mantenha até 3 frases, termine com a assinatura em linha própria e avise o usuário com **[PRECISA DE VOCÊ]**. Os horários nos exemplos são ilustrativos: use o prazo de retorno de `dados-da-loja.md` ou `[confirmar: horário do retorno]`. Se a mensagem cair em mais de um caso, combine os modelos.

## Cliente bravo ou reclamação
Peça desculpa pelo problema sem discutir quem tem razão, mostre que entendeu o que aconteceu e diga quando terá retorno.
> "Oi, Ana. Sinto muito pelo bolo ter chegado amassado, não é isso que a gente quer pra você. Já passei pra responsável e te retorno até as 16h com a solução.
> — Equipe Doce Lar"

## Pedido de desconto
Não negue nem conceda. Diga que vai ver o que dá pra fazer.
> "Oi! Vou ver com a responsável o que consigo pra você e já te respondo, tá?
> — Equipe Doce Lar"

## Cancelamento, troca ou reembolso
Confirme que recebeu o pedido e explique o próximo passo. Só cite a política se ela estiver em `dados-da-loja.md`.
> "Recebido, Carlos. Vou registrar o cancelamento da encomenda de sábado e te confirmo aqui como fica o sinal ainda hoje.
> — Equipe Doce Lar"

## Atraso na entrega
Dê a informação que tiver. Se não souber o novo horário, diga que vai verificar.
> "Oi! Seu pedido saiu às 17h20 e está a caminho. Vou confirmar com o entregador o horário exato e te aviso. Desculpa a demora!
> — Equipe Doce Lar"

## Fora do horário
Diga quando a loja volta e o que o cliente pode fazer até lá.
> "Oi! Agora estamos fechados, voltamos amanhã às 9h. Se quiser, já me deixa o pedido aqui que eu confirmo logo cedo.
> — Equipe Doce Lar"

## Pergunta que a skill não sabe responder
Nunca invente. Se o usuário já sabe a resposta, use `[confirmar: ...]` e pergunte a ele; se ele pediu mensagem pronta para colar, diga ao cliente que vai confirmar:
> "Boa pergunta! Vou confirmar se dá pra fazer sem lactose e já te falo.
> — Equipe Doce Lar"

## Elogio ou avaliação positiva
Agradeça com algo específico do que o cliente disse e, se fizer sentido, convide pra voltar.
> "Que bom que a família gostou da torta de limão! Obrigado por contar, isso alegra o dia da cozinha. Te esperamos de novo.
> — Equipe Doce Lar"
