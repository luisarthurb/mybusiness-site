# Dados da loja

A skill só afirma o que está aqui. Preencha uma vez e atualize quando algo mudar (horário de feriado, taxa nova, produto que saiu). Os campos **(obrigatório)** precisam estar preenchidos; os outros você pode apagar se não se aplicam.

## Básico
- Nome (obrigatório): <nome da loja>
- Assinatura (obrigatório): <ex.: Equipe Doce Lar>
- Endereço: <rua, número, bairro, cidade>
- Link do mapa: <link do Google Maps>
- Horário (obrigatório): <ex.: seg a sáb, 9h às 18h; domingo fechado>
- Feriados e datas especiais: <ex.: 24/12 até 14h>

## Pedidos e entrega
- Como pedir (obrigatório): <WhatsApp, site, iFood…>
- Cardápio ou catálogo: <link>
- Entrega (obrigatório se entrega): <bairros atendidos>
- Taxa de entrega: <valor por bairro ou faixa>
- Prazo de entrega: <ex.: até 1h depois do pedido>
- Último pedido do dia: <ex.: 19h30 para entrega, 19h45 para retirada>
- Encomendas: <antecedência mínima, sinal, como confirmar>
- Retirada: <onde e em que horário>

## Pagamento
- Formas aceitas (obrigatório): <Pix, cartão, dinheiro…>
- Chave Pix: <só se a loja quiser que a skill envie>
- Sinal para encomenda: <valor ou %>

## Políticas
- Troca e devolução: <regra>
- Cancelamento de encomenda: <até quando, devolve o sinal?>
- Atraso na entrega: <o que a loja oferece; vazio = a skill não oferece nada>
- Prazo de retorno ao cliente: <ex.: até 2h em horário de funcionamento; vazio = a skill pergunta a você>

## Tom da casa
- Trata o cliente por: <você / senhor(a) / nome>
- Usa emoji? <não / só um, no fim>
- Palavras da marca: <ex.: "fornada", "mimo">
- Nunca dizer: <ex.: "infelizmente", "não é possível">

## Perguntas frequentes
Coloque aqui as respostas que você mais repete, uma por linha:
- <pergunta>: <resposta>
